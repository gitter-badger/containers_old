#!/bin/sh

#=================== N-O-V-O-R ===================
#   NOVOR: Real-time Peptide de Novo Sequencing   
#              Free Academic License
#=============== www.rapidnovor.org ==============
#
# This trial license can be used for evaluation purposes only

if test -n "${JAVA_HOME}"; then
	if test -z "${JAVA_EXE}"; then
		JAVA_EXE=$JAVA_HOME/bin/java
	fi
fi

if test -z "${JAVA_EXE}"; then
	JAVA_EXE=java
fi

NULL=`$JAVA_EXE -version`
if [ $? -ne 0 ]; then
	echo "java command not found, please set JAVA_HOME or PATH environment variable."
	exit 1
fi

BIT=`$JAVA_EXE -version 2>&1 | grep -o "64-Bit"`
if test -n "${BIT}"; then
	JVMOPT="-Xms2g -Xmx4g"
else
	JVMOPT="-Xms1g -Xmx2g"
fi

script=`/bin/ls -l $0 | awk '{ print $NF; }'`
while test -h "$script"; do
	script=`/bin/ls -l $script | awk '{ print $NF; }'`
done

NOVOR_HOME=`dirname $script`
NOVOR_JAR="$NOVOR_HOME/lib/novor.jar"

PARAM=""
until [ $# -eq 0 ]; do
	PARAM="$PARAM $1"
	shift
done

exec $JAVA_EXE $JVMOPT -jar $NOVOR_JAR $PARAM
